# TV Finder Web Design Assessment

A responsive front-end TV search tool using the TVMaze API.

## Files
- `index.html` - page structure and accessible search form
- `styles.css` - responsive layout, cards and accessibility focus states
- `script.js` - fetch request to TVMaze, JSON handling and DOM rendering

## How to run locally
Open `index.html` in a browser, or use a local server such as VS Code Live Server.

## API endpoint used
`https://api.tvmaze.com/search/shows?q=SEARCH_TERM`

## Submission steps
1. Create a GitHub repository.
2. Upload these files and make several commits if possible.
3. Publish the site using GitHub Pages or Netlify.
4. Replace the placeholder Live Website URL and GitHub URL in the report.
